<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
</head>
<body>
    <h2>Register</h2>
    <?php if($errors->any()): ?>
        <div>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($err); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(url('/register')); ?>">
        <?php echo csrf_field(); ?>
        <div>
            <label>Name</label>
            <input type="text" name="name" value="<?php echo e(old('name')); ?>" required>
        </div>
        <div>
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" required>
        </div>
        <div>
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div>
            <label>Confirm Password</label>
            <input type="password" name="password_confirmation" required>
        </div>
        <button type="submit">Register</button>
    </form>

    <p>Already have an account? <a href="<?php echo e(url('/login')); ?>">Login</a></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\komentar\WAD_Week7\resources\views/register.blade.php ENDPATH**/ ?>